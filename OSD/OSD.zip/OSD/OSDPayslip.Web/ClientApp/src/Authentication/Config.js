module.exports = {
    appId: '225477a8-2638-4ede-b006-484ca273b8e5',
    scopes: [
      "user.read",
      "calendars.read",
      "mail.send"
    ]
  };