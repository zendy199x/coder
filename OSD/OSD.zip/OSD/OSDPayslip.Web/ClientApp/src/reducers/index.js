import { combineReducers } from 'redux';

const appReducers = combineReducers({

});

export default appReducers;