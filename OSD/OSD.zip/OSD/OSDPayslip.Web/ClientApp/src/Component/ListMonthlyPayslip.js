import React, { Component } from 'react';
import { Stack } from 'office-ui-fabric-react/lib/Stack';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import ButtonDialog from './ButtonDialog';
import EmployeeList from '../components/EmployeeList/EmployeeList'
import { BrowserRouter as Router,  Link} from "react-router-dom";

class ListPayslip extends Component {
    render() {
        // var employees = [
        //     {reqNo: "123456", reqDate: new Date(2011,10,30), noOfEmployee: 150, status: "Success", createdBy: "123@gmail.com"},
        //     {reqNo: "456789", reqDate: new Date(2011,10,29), noOfEmployee: 120, status: "Failed", createdBy: "123@gmail.com"},
        //     {reqNo: "987654", reqDate: new Date(2011,10,28), noOfEmployee: 130, status: "Success", createdBy: "123@gmail.com"}
        // ];

        return (
            <div className="Paylist">
                <h3 className="title">
                    Monthly Payslip Request
                </h3>
                <div className="find">
                    <Stack >
                        <TextField type="number" placeholder="Search by Date" />
                    </Stack>
                </div>
                <div className="send">
                    <ButtonDialog />
                </div>
                <div>
                    <EmployeeList />
                </div>
                </div>
            );
        }
    };
export default ListPayslip;
