// import React, { Component } from 'react';
import * as React from 'react';  
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { ChoiceGroup, Dropdown, Button } from 'office-ui-fabric-react/lib';

class ButtonDialog extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            hideDialog: true
        }
    }

    showDialog = () => {
        this.setState({ hideDialog: false });
    };

    closeDialog = () => {
        this.setState({ hideDialog: true });
    };

    render() {
        const { selectedItem } = this.state;
        return (
            <div>
                <DefaultButton secondaryText="Opens the Sample Dialog" onClick={this.showDialog} text="Create New Request" />
                <Dialog
                    hidden={this.state.hideDialog}
                    onDismiss={this.closeDialog}
                    dialogContentProps={{
                        type: DialogType.largeHeader,
                        title: 'Create New Request',
                        subText: 'Upload file payslip format excel'
                    }}
                    modalProps={{
                        isBlocking: false,
                        styles: { main: { maxWidth: 450 } }
                    }}
                    >
                    <h5>Payslip ata:</h5>
                    <input type="file" id="files" name="files" />
                    <Dropdown
                        className='Dropdown-payslip'
                        placeholder="Select month payslip"
                        label='Payslip for:'
                        defaultSelectedKey='Jan'
                        disabled={ false }
                        options={
                        [
                            { key: 'Jan', text: 'January' },
                            { key: 'Feb', text: 'February' },
                            { key: 'Mar', text: 'March' },
                            { key: 'Apr', text: 'April' },
                            { key: 'May', text: 'May' },
                            { key: 'Jun', text: 'June' },
                            { key: 'Jul', text: 'July' },
                            { key: 'Aug', text: 'August' },
                            { key: 'Sep', text: 'September' },
                            { key: 'Oct', text: 'October' },
                            { key: 'Nov', text: 'November' },
                            { key: 'Dec', text: 'December' },
                        ]
                        }
                    />
                    <DialogFooter>
                        <PrimaryButton onClick={this.getUpload} text="Create" />
                        <DefaultButton onClick={this.closeDialog} text="Cancel" />
                    </DialogFooter>
                </Dialog>
            </div>
        );
    }
}

export default ButtonDialog;
