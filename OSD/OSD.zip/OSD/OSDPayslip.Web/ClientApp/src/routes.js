import React from 'react';
import NotFoundPage from './pages/NotFoundPage/NotFoundPage';
import PayslipReport from './Component/PayslipReport'
import ListPayslip from './Component/ListPayslip';
import ListMonthlyPayslip from './Component/ListMonthlyPayslip';

const routes = [
    {
        path: '/',
        exact: true,
        main: () => <ListMonthlyPayslip />
    },
    {
        path: '/report',
        exact: false,
        main: () => <PayslipReport />
    },
    {
        path: '/list',
        exact: false,
        main: () => <ListPayslip />
    },
    {
        path: '',
        exact: false,
        main: () => <NotFoundPage />
    }
];

export default routes;