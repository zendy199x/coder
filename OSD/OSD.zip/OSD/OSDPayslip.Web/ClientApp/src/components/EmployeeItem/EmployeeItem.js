import React, { Component } from "react";
import { Stack } from "office-ui-fabric-react/lib/Stack";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { BrowserRouter as Router, Link } from "react-router-dom";

class EmployeeItem extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    var req = this.props.request;
    console.log(req)

    return (
      <React.Fragment>
        {req.map(item => (
          <tr className="ms-Table-row" key={item.Id}>
            <td className="ms-Table-cell">{item.Id}</td>
            <td className="ms-Table-cell">
                {item.CreateDate.slice(8,10) + '-' + item.CreateDate.slice(5,7) + '-' + item.CreateDate.slice(0,4) + ' | ' + item.CreateDate.slice(11,16)}
            </td>
            <td className="ms-Table-cell">{item.NoOfDeployee}</td>
            <td className="ms-Table-cell">{item.PayslipForMonth}</td>
            <td className="ms-Table-cell">{item.CreateBy}</td>
            <td className="ms-Table-cell">
                {item.Status === 0 ? (<p style={{color: 'red'}}>New</p>) : item.Status === 1 ? (<p style={{color: 'yellow'}}>Partially Sent</p>) : (<p style={{color: 'green'}}>Fully Sent</p>)}
            </td>
            <td className="ms-Table-cell">
              <button className="ms-Button">
                <span className="ms-Button-label">
                  <Link to="/list">Open</Link>
                </span>
              </button>
            </td>
          </tr>
        ))}
      </React.Fragment>
    );
  }
}

export default EmployeeItem;
