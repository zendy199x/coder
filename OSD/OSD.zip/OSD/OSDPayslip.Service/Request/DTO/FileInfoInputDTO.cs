﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OSDPayslip.Service.Request.DTO
{
    public class FileInfoInputDTO
    {
        public int PayslipForMonth;
        public object File;
    }
}
